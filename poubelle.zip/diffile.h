/* Dif File management */


// on represnete les date/heure sur 64 bits avec le codage Win32
// (plus precis que celui du DOS qui ne connait que les secondes paires...)
#ifndef _WINBASE_
typedef struct _FILETIME
{                               // ft
  DWORD dwLowDateTime;
  DWORD dwHighDateTime;
}
FILETIME;
#endif

#define TR_INSERTNEW    (1)
#define TR_PATCH        (2)
#define TR_EXIST        (3)

typedef enum
{
  TS_DIRECTORY_LIST = 1,
  TS_DIRECTORY,
  TS_INSERTNEW,
  TS_PATCHLISTSEQ,
  TS_PATCHDATA
}
TAG_TYPESECTION;

#define METHCOMPR_DEFLATE (8)

// une section qcq commence par SECTION et est suivi des donnees (compresse)
typedef struct
{
  DWORD dwSizeCompressed;
  DWORD dwSizeUnCompressed;
  DWORD dwCrcCompressed;
  DWORD dwCrcUnCompressed;

// dwTypeSection : TS_DIRECTORY_LIST, TS_DIRECTORY, TS_INSERTNEW,
//          TS_PATCHLISTSEQ ou TS_PATCHDATA
  DWORD dwTypeSection;
// dwMethCompr=8 : deflate, dwMethCompr=0 : store
  DWORD dwMethCompr;
  DWORD dwPosition;
  DWORD dwRes0;
}
SECTION;

typedef struct
{
  DWORD dwSizeCompressed;
  DWORD dwSizeUnCompressed;
  DWORD dwTypeSection;
  DWORD dwPosition;
}
SECTIONINDIR;




// Premiere specification du fichier de patch
// a ajouter : specification pour le decoupage en volume style ARJ
// (qui devra etre transparent par rapport au format de fichier)

// Les structures ne sont pas optimises a fond, mais sont destinee a
// etre compresse par un Deflate...


/*
 GVD_GENERALINDEX est l'endroit qui permet d'attaquer le fichier. Il
 se trouve physiquement au debut (ou tout a la fin du fichier
 si au debut dwOffsetDirectoryList=0xFFFFFFFF)

 lFirst est le numero du premier directory, lLatest celui du dernier+1
 Le nombre de directory est lLatest-lFirst
 on a lFirst<=lLatest (quoique lFirst==lLatest : fichier vide !)
 Le zero n'a pas de signification. Ainsi on peut supprimer le premier
 directory...

  lDirection est la direction des patchs : si lDirection==+1
   les fichiers du directory n sont construit a partir des fichiers des
   directory < n, (et > n si lDirection==-1)

  dwOffsetDirectoryList est l'offset dans le fichier de patch du tableau
  de structure GVD_DIRECTORY_LIST_ITEM (dont le nombre d'element est le
  nombre de directory lLatest-lFirst)
*/
typedef struct
{
  DWORD dwMagic;                // 'GVFL' ?
  DWORD dwMagicEnd;             // must be null (be space for text after)
//
  DWORD dwVersion;
  DWORD dwVersionMin;
  SECTIONINDIR sidDirectoryList;
}
GVD_GENERALINDEX;

/*
GVD_DIRECTORY_LIST_HEADER est suivis de dwNbDirectory structures GVD_DIRECTORY_LIST_ITEM
puis de dwSizeInfoSpecial octets d'info special
*/

typedef struct
{
  DWORD dwNbDirectory;
  DWORD dwSpecialDirListInfoSize;
  DWORD dwVersion;
  DWORD dwVersionMin;

  LONG lFirst;
  LONG lLatest;
  LONG lDirection;
}
GVD_DIRECTORY_LIST_HEADER;
/*
GVD_DIRECTORY_LIST_ITEM index des directory
dwDirectoryOffset : offset du directory dans le fichier de patch
dwDirectoryCompressionMethod : 8 pour Deflate,0 pour Store
        (valeur standard des fichiers .ZIP)
dwDirectoryCompressedSize : taille compresse du directory
dwDirectoryUnCompressedSize : taille decompresse du directory
dwDirectoryUnCompressedCRC : CRC32 du directory decompresse
*/

typedef struct
{
  long lDirNum;
  DWORD dwRes0;
  DWORD dwRes1;
  SECTIONINDIR sidDirectorySection;
}
GVD_DIRECTORY_LIST_ITEM;

/***************************************************************************/
/* Pour chaque fichier du directory puis pour le rep.,
   et enfin pour le fichier complet, nous utilisons un
   systeme de tags (inspire un peu de RockRidge CD)
   Nous avons des structures GVD_SPECIAL_INFO dont le debut precise le tag
   et la taille de l'info, puis des octets dont la signification depend du
   tag. La taille doit etre multiple de 4 (alignement DWORD)
   Nous pouvons avoir plusieurs GVD_SPECIAL_INFO qui se suivent,
   nous connaissons la taile de l'ensemble des tags pour stopper
   Les commentaires iront dedans... */
/***************************************************************************/
typedef struct
{
  DWORD dwSizeInfo;
  DWORD dwTagInfo;
// here we have dwSizeInfo - 2*(sizeof(DWORD)) byte for the info
}
GVD_SPECIAL_INFO_HEADER;

typedef struct
{
  GVD_SPECIAL_INFO_HEADER siHeader;
  DWORD dw[1];
}
GVD_SPECIAL_INFO;
/***************************************************************************/

/***************************************************************************/
/* Un directory commence par un GVD_DIRECTORY_HEADER, puis
   contient dwNumberFiles representations de fichiers qui a elles toutes
   occupent dwSizeFiles octets, puis dwSpecialDirectoryInfoSize octets de
   tags specials info attache au repertoire */
/***************************************************************************/
typedef struct
{
  DWORD dwNumberFiles;
  DWORD dwSizeFiles;
  DWORD dwSpecialDirectoryInfoSize;
  DWORD dwRes;
}
GVD_DIRECTORY_HEADER;

/*
Un fichier se presente sous la forme :
- une structure GVD_DIRECTORY_FILEENTRY_HEADER
- Le nom du fichier (Unicode), puis un zero terminal, puis des zeros pour se realigner
  sur une frontiere de 4 octets
- dwNbSection structures SECTIONINDIR
- dwNbIgnoreCrcEntry structures GVD_DIRECTORY_IGNORE_CRC_ENTRY
- dwNbSrcEntry structures GVD_DIRECTORY_SRCENTRY
- dwSpecialFileInfoSize octets de tags d'info special
Le tout occupre dwSizeFileInDirectory octets
*/
typedef struct
{
// dwSizeFileInDirectory : taille totale des infos du fichiers
  DWORD dwSizeFileInDirectory;
// ftFile : Date heure du fichier
  FILETIME ftFile;

// dwCrc : CRC du fichier (moins les zones GVD_DIRECTORY_IGNORE_CRC_ENTRY
//        destines aux numeros de serie)
  DWORD dwCrc;

// dwFileSize : taille du fichier
  DWORD dwFileSize;
// dwTypeRepresent : TR_INSERTNEW pour une insertion de fichier nouveau
//                   TR_PATCH pour un patch construit
//                   TR_EXIST pour un fichier que l'utilisateur a deja
  DWORD dwTypeRepresent;
// dwStorageMethod : if dwTypeRepresent=TR_PATCH, patch version
// (0x10000 : version 1.0, 0x10a00 : 1.10, 0x10a01 : 1.10a)
  DWORD dwStorageMethod;
// dwCompressionLevel : degree de compression/recherche de patch
//  (juste pour info, comme le flag correspondant des ZIP...)

// dwSizeFileName : taille du nom de fichier (non compris les '\0')
// taille occuppe : Round4((dwSizeFileName+1)*2)
  DWORD dwSizeFileName;

// dwNbSection : nombre de structure SECTIONINDIR
  DWORD dwNbSection;

// dwNbIgnoreCrcEntry : nb de structure GVD_DIRECTORY_IGNORE_CRC_ENTRY
  DWORD dwNbIgnoreCrcEntry;

// dwNbSrcEntry : used only if dwTypeRepresent=TR_PATCH
//   (premiere beta du soft : dwNbSrcEntry=1)
  DWORD dwNbSrcEntry;

// dwSpecialFileInfoSize : taille des tags d'info specials
  DWORD dwSpecialFileInfoSize;
}
GVD_DIRECTORY_FILEENTRY_HEADER;

/*
GVD_DIRECTORY_IGNORE_CRC_ENTRY : decrit les chaines contenant dans le fichier
  recree les numeros de serie a ignorer pour le calcul de CRC
  (a ne pas implementer immediatement)
*/
typedef struct
{
  DWORD dwOffsetBegin;          // l'offset se refere au fichier recree et non au patch!
  DWORD dwOffsetEnd;
}
GVD_DIRECTORY_IGNORE_CRC_ENTRY;


/*
GVD_DIRECTORY_SRCENTRY : permet de connaitre la source du patch
(fichier precedent).
Premiere beta du soft : on en a un seul (dwNbSrcEntry=1),
dwOffsetBegin=0 et dwOffsetEnd taille du fichier source

Ensuite, on pourra imaginer de recreer un patch a partir de pluisieurs fichiers
sources,
que l'on collera virtuellement bout a bout au moment de reconstituer le fichier
*/
typedef struct
{
  LONG lDir;
  DWORD dwFilePosInDir;
  DWORD dwOffsetBegin;          // l'offset se refere au fichier source et non au patch!
  DWORD dwOffsetEnd;
}
GVD_DIRECTORY_SRCENTRY;

/***************************************************************************/

// A patch in the file begin with a :
// (dwFileOffset pointe dessus si dwTypeRepresent == TR_PATCH)
// ici, les offset se refere au fichier patch,
// Seq correspond au sequence tel que l'entend GVDif
// et Repr a la suite des chaines nouvelle insere a l'occasion du patch
typedef struct
{
  DWORD dwSeqUnCompressedSize;
  DWORD dwSeqCompressedSize;
  DWORD dwSeqOffset;
  DWORD dwSeqCrc;
  DWORD dwReprUnCompressedSize;
  DWORD dwReprCompressedSize;
  DWORD dwReprOffset;
  DWORD dwReprCrc;
}
GVD_PATCH_HEADER;


/*
Le premier header (GVD_GENERALINDEX) devrait toujours etre en tete de fichier. Dans ton commentaire, tu dis:

/ *
 GVD_GENERALINDEX est l'endroit qui permet d'attaquer le fichier. Il
 se trouve physiquement au debut (ou tout a la fin du fichier
 si au debut dwOffsetDirectoryList=0xFFFFFFFF)

Certes, mais dwOffsetDirectoryList est un champ de GVD_GENERALINDEX, alors je ne comprends pas bien comment il peut indiquer l'emplacement physique de l'index... ca voudrait dire qu'on lit d'abord le debut du fichier et si on ne trouve pas l'en-tete, il faut aller a la fin et lire la fin du fichier ? ca me parait pas tres efficace...

Pour dwMagicEnd, je verrais plutot une chaine unicode
WCHAR wstr[6] ou wstr[8] qui permet de coder un nom court pour le nom du logiciel.

LONG pour la direction ??? pourquoi pas un DWORD pour des flags qui contiendrait la direction et d'autres flags supplementaires (par exemple:
LITTLE or BIG endian storage format (je ne sais pas, c'est peut-etre completement inutile)
spanning flag: indique si ce patch est sur plusieurs disquettes.
il faudrait alors avoir egalement dwPatchSize, dwSpanSize, dwMaxSpanNumber, dwSpanNumber. Ca me parait plus clair que dwMaxFileSize, dwNoFile...

lFirst: pourquoi pas lFirstDirectory?
lLatest: lLastDirectory? numero du dernier directory. Est-on garanti que les directories portent des numeros consecutifs ?
Si oui, on pourrait avoir countDirectory: nombre de directories

GVD_SPECIAL_INFO ??? GVD_TAG_INFO ???
Il est peut-etre plus simple de definir une structure par type de tag avec info de taille fixe et une structure de tag generique (info taille variable) on aurait alors:

// taille variable (cas general)
DWORD dwTagID;  // type de tag, ce qui permet de savoir de reconnaitre les tags7 connus et ceux a ignorer
DWORD dwTagSize;    // taille du tag, y compris info suivant le tag - alignee sur un DWORD, de facon a ce qu'on puisse skipper le tag tres facilement si on ne le connait pas (cas de la version 1 qui permet de lire un fichier qui contient un tag defini par la version 2)
// info de taille dwTagSize - 2 * sizeof(DWORD)

// tag de taille fixe
DWORD dwTagID;  // type de tag, ce qui permet de savoir de reconnaitre les tags connus et ceux a ignorer
DWORD dwTagSize;    // taille du tag, y compris info suivant le tag
...
GVD_SPECIAL_INFO ne me parait pas necessaire dans ce contexte, quand on trouve un tag, il suffit de soit le lire soit le skipper...
*/

#define Round4(x) ((((x)+3)/4)*4)

#define DwordFromDiskStruct(x) ((DWORD)(x))
#define DwordToDiskStruct(x) ((DWORD)(x))
#define LongFromDiskStruct(x) ((long)(x))
#define LongToDiskStruct(x) ((long)(x)))
