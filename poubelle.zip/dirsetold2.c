#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <windows.h>

#include "difbasic.h"

#include "DfsTlTyp.h"
#include "difstool.h"
#include "DfsStruc.h"
#include "DfsTagDf.h"
#include "DfsTagMg.h"

#include "DfsIntf.h"
#include "DfsSet.h"
#include "DfsWrSet.h"
#include "DfsRdSet.h"
#include "DfsCdLin.h"
#include "ArrayTl.h"


#include "DfsIoHlp.h"
/*
#include "ltools.h"
*/
#include "DirSet.h"



void FreeFileSet(FILESET * pfs, BOOL fDeleteFile)
{
  dfuLong32 i;
  if (pfs->dfNbFileItem == 0)
    return;
  if (pfs->pFileItem == NULL)
    return;


  for (i = 0; i < pfs->dfNbFileItem; i++)
  {
    FILEITEM *pfi = (pfs->pFileItem) + i;
    if (pfi->FileNameOnArchive != NULL)
      DfsFree((dfwcharp) (pfi->FileNameOnArchive));
    if (pfi->FileNameOnDisk != NULL)
    {
      if (fDeleteFile && (pfi->fTempFile))
        MyDeleteFileW(pfi->FileNameOnDisk);

      DfsFree((dfwcharp) (pfi->FileNameOnDisk));
    }
  }
  DeleteArray(pfs->pFileItem);
  pfs->pFileItem = NULL;
  pfs->dfFileItemAllocated = 0;
  pfs->dfNbFileItem = 0;
  pfs->fTempFile = FALSE;
}

void InitFileSet(FILESET * pfs)
{
  pfs->pFileItem = NULL;
  pfs->dfFileItemAllocated = 0;
  pfs->dfNbFileItem = 0;
  pfs->dfFileItemStepAlloc = 0x10;
  pfs->fTempFile = FALSE;
}



BOOL AddItemToFileSet(FILESET * pfs, const FILEITEM * lpfi,
                      dfuLong32 dfNbFileItem)
{
  pfs->pFileItem =
    (FILEITEM *) AddArrayElem(pfs->pFileItem, &pfs->dfNbFileItem,
                              &pfs->dfFileItemAllocated,
                              pfs->dfFileItemStepAlloc, sizeof(FILEITEM),
                              lpfi, dfNbFileItem);
  return TRUE;
}

long fncCompareFileItem(const void *lpElem1, const void *lpElem2)
{
  const FILEITEM *pfi1 = (const FILEITEM *) lpElem1;
  const FILEITEM *pfi2 = (const FILEITEM *) lpElem2;
  return dfUnicodeStrcmpi(pfi1->FileNameOnArchive, pfi2->FileNameOnArchive);
}

BOOL fncDestructorFileItem(const void *lpElem)
{
  FILEITEM *pfi = (FILEITEM *) lpElem;
  if (pfi->FileNameOnArchive != NULL)
    DfsFree((dfwcharp) pfi->FileNameOnArchive);
  if (pfi->FileNameOnDisk != NULL)
    DfsFree((dfwcharp) pfi->FileNameOnDisk);

  return TRUE;
}

BOOL ExtractPatch(DFSFILE DfsFile, FILESET * pfsOrg, FILESET * pfsDest,
                  dfuLong32 dfNumDirBase,
                  BOOL fNewFileSetTemp, BOOL fOldFileCanBeCaptured,
                  dfwcharpc szBasePath,
                  tProgressCallBack pProgressCallBack, dfvoidp dfUserPtr)
{
  /* Note : if fNewFileSetTemp is FALSE, we use the filename in (pfsDest+#)->FileNameOnDisk
     Else we build a temp filename
   */
  dfuLong32 i;
  dfuLong32 dfError = DFS_SUCCESS;
  FILETOEXTRACT *pftx;

  pftx =
    (FILETOEXTRACT *) DfsMalloc(sizeof(FILETOEXTRACT) *
                                (pfsDest->dfNbFileItem + 1));

  for (i = 0; i < pfsDest->dfNbFileItem; i++)
  {
    dfuLong32 dfPreviousVersion;
    (pftx + i)->fCorrectlyDone = FALSE;
    (pftx + i)->fIgnore = (pfsDest->pFileItem + i)->fIgnore;
    (pftx + i)->filename_ondisk_towrite=NULL;
    (pftx + i)->filename_ondisk_previous_toread = NULL;

    if (!(pftx + i)->fIgnore)
    {
        dfPreviousVersion = (pfsDest->pFileItem + i)->dfPreviousVersion;

        if (!fNewFileSetTemp)
          (pftx + i)->filename_ondisk_towrite =
            dfUnicodeCopyConcatAlloc((pfsDest->pFileItem + i)->FileNameOnDisk,
                                     NULL);
        else
        {
          BOOL fCanCapturePrevious;
          fCanCapturePrevious =
              (fNewFileSetTemp && fOldFileCanBeCaptured
                && ((pfsDest->pFileItem + i)->fIdenticalPreviousVersion)
                && (dfPreviousVersion != VALUE_UNKNOWN) && (pfsOrg != NULL));
          if (fCanCapturePrevious)
          {
              (pftx + i)->fIgnore = TRUE;
              (pfsDest->pFileItem + i)->FileNameOnDisk =
                  dfUnicodeCopyConcatAlloc(((pfsOrg->pFileItem) +
                                      dfPreviousVersion)->FileNameOnDisk, NULL);
              (pfsDest->pFileItem + i)->fTempFile = ((pfsOrg->pFileItem) + dfPreviousVersion)->fTempFile;
              ((pfsOrg->pFileItem) + dfPreviousVersion)->fTempFile=FALSE;
              //*(dfwcharp)(((pfsOrg->pFileItem) + dfPreviousVersion)->FileNameOnDisk) = 0; // to no delete
          }
          else
          {
            dfwchar szTempFN[1024 + MAX_PATH];
            if (IsUnicodeSupported())
            {
              GetTempFileNameW(L".", L"DFS", 0, szTempFN);
            }
            else
            {
              char szAnsiTempFN[MAX_PATH];
              GetTempFileNameA(".", "DFS", 0, szAnsiTempFN);
              ConvertAnsiToUnicode(szAnsiTempFN, szTempFN,
                                   sizeof(szTempFN) / sizeof(dfwchar));
            }

            (pftx + i)->filename_ondisk_towrite =
              dfUnicodeCopyConcatAlloc(szTempFN, NULL);

            if ((pfsDest->pFileItem + i)->FileNameOnDisk != NULL)
              DfsFree((dfwcharp) (pfsDest->pFileItem + i)->FileNameOnDisk);
            (pfsDest->pFileItem + i)->FileNameOnDisk =
              dfUnicodeCopyConcatAlloc(szTempFN, NULL);
            (pfsDest->pFileItem + i)->fTempFile = TRUE;
            (pfsDest->pFileItem + i)->fIdenticalPreviousVersion = FALSE;
          }
        }
        if ((dfPreviousVersion != VALUE_UNKNOWN) && (pfsOrg != NULL))
          (pftx + i)->filename_ondisk_previous_toread =
            dfUnicodeCopyConcatAlloc(((pfsOrg->pFileItem) +
                                      dfPreviousVersion)->FileNameOnDisk, NULL);
    }
  }
  dfError =
    ExtractDirectory(DfsFile, dfNumDirBase + 0, pfsDest->dfNbFileItem, pftx,
                     pProgressCallBack, dfUserPtr);

  for (i = 0; (i < pfsDest->dfNbFileItem) && (dfError == DFS_SUCCESS); i++)
    if ((!(pftx + i)->fCorrectlyDone) && (!(pftx + i)->fIgnore))
      dfError = DFS_ERROR_ERRORIO;

#if defined(_DEBUG) && defined(_CONSOLE)
  for (i = 0; i < pfsDest->dfNbFileItem; i++)
  {
    if ((!(pftx + i)->fCorrectlyDone) && (!(pftx + i)->fIgnore))
      printf("File '%ws'-'%ws' badly extracted on version %u\n",
             ((pfsDest->pFileItem) + i)->FileNameOnArchive,
             (pftx + i)->filename_ondisk_towrite, dfNumDirBase);
  }
#endif
#if defined(_DEBUG) && !defined(_CONSOLE)
  for (i = 0; i < pfsDest->dfNbFileItem; i++)
  {
    if ((!(pftx + i)->fCorrectlyDone) && (!(pftx + i)->fIgnore))
    {
        TCHAR sz[MAX_PATH*2];
      wsprintf(sz,"\nFile '%ws'-'%ws' (from old %ws) badly extracted on version %u\n",
             ((pfsDest->pFileItem) + i)->FileNameOnArchive,
             (pftx + i)->filename_ondisk_towrite,
             ((pftx + i)->filename_ondisk_previous_toread != NULL) ? (pftx + i)->filename_ondisk_previous_toread : L"(no)",
             dfNumDirBase);
        OutputDebugString(sz);
    }
  }
#endif


  for (i = 0; i < pfsDest->dfNbFileItem; i++)
  {
    if ((pftx + i)->filename_ondisk_towrite != NULL)
      DfsFree((dfwcharp) (pftx + i)->filename_ondisk_towrite);
    if ((pftx + i)->filename_ondisk_previous_toread != NULL)
      DfsFree((dfwcharp) (pftx + i)->filename_ondisk_previous_toread);
  }
  DfsFree(pftx);
/*
  if (pfsOrg != NULL)
  {
    //FreeFileSet(pfsOrg,TRUE);
    FreeFileSet(pfsOrg, pfsOrg->fTempFile);
  }
*/
  return dfError;
}


dfuLong32 CreateFileSetForVersionInDirectory(DFSFILE DfsFile, FILESET * pfs, dfuLong32 dfNumDir, dfwcharpc szDirBase, BOOL * pfComplete,    // Will receive BOOL to known if all is good
                                           BOOL fVerboseNotFound,       // if must do printf for error
                                           BOOL fFillNameOnDisk,
                                           BOOL
                                           fTryFindFileOnDiskIfNotInsertingInDfs,
                                           BOOL
                                           fTryFindFileOnDiskIfInsertingInDfs,
                                           dfuLong32 * pdfTypeDir,
                                           BOOL fFillFileDateFromDisk)
{
  dfuLong32 dfError;
  PDIRINFO pDirInfo = NULL;
  dfwcharp szDirBaseUse;
  dfuLong32 dfDirBaseLen = dfUnicodeStrlen(szDirBase);
  BOOL fTryFindFileOnDisk;
  if (pfComplete != NULL)
    *pfComplete = TRUE;

  if (dfDirBaseLen == 0)
    szDirBaseUse = dfUnicodeCopyConcatAlloc(NULL, NULL);
  else
  {
    dfuLong32 dfDirBaseLen = dfUnicodeStrlen(szDirBase);
    if (((*(szDirBase + dfDirBaseLen - 1)) == '\\') ||
        ((*(szDirBase + dfDirBaseLen - 1)) == ':'))
      szDirBaseUse = dfUnicodeCopyConcatAlloc(szDirBase, NULL);
    else
      szDirBaseUse = dfUnicodeCopyConcatAlloc(szDirBase, L"\\");
  }

  FreeFileSet(pfs, FALSE);
  dfError = ReadDirectoryInfo(DfsFile, dfNumDir, &pDirInfo, NULL, NULL);
  if (dfError == DFS_SUCCESS)
  {
    if (pdfTypeDir != NULL)
      *pdfTypeDir = pDirInfo->dfTypeDir;
    if ((pDirInfo->dfTypeDir == TYPEDIR_FILEINSERTING_DEFLATE) ||
        (pDirInfo->dfTypeDir == TYPEDIR_FILEINSERTING_STORE))
      fTryFindFileOnDisk = fTryFindFileOnDiskIfInsertingInDfs;
    else
      fTryFindFileOnDisk = fTryFindFileOnDiskIfNotInsertingInDfs;
  }




  if (dfError == DFS_SUCCESS)
  {
    dfuLong32 i;
    dfuLong32 dfGetNbFile = pDirInfo->dfNbFile;
    for (i = 0; i < dfGetNbFile; i++)
    {
      FILEITEM fi;
      dfwcharp FileNameOnDisk=NULL;
      dfuLong32 dfSize;
      dfvoidp TagBuf;
      dfuLong32 TagSize;

      fi.fTempFile = FALSE;
      fi.fIdenticalPreviousVersion = FALSE;
      fi.fIgnore=FALSE;
      fi.fForceDate=FALSE;
      fi.fAddNewTag = FALSE;
      fi.pReserved = NULL;
      fi.FileNameOnArchive =
        dfUnicodeCopyConcatAlloc((pDirInfo->pFileInDirInfo + i)->FileName,
                                 NULL);
      fi.FileNameOnDisk = NULL;
      fi.dfPreviousVersion = VALUE_UNKNOWN;
      if (GetTag
          (*(pDirInfo->TagFile + i), DFSTAG_STORAGESTATUS, &TagBuf, &TagSize))
      {
        dfuLong32 dfFileIdentical =
          ConvertuLongIntelToLong(*(dfuLong32Intel *) TagBuf);
        if (dfFileIdentical == DFS_STORAGESTATUS_IDENTICAL)
          fi.fIdenticalPreviousVersion = TRUE;
      }
      if (GetTag
          (*(pDirInfo->TagFile + i), DFSTAG_PREVIOUSVERSIONINFO, &TagBuf,
           &TagSize))
      {
        if (TagSize <= sizeof(DFSPREVIOUSVERSIONINFO))
        {
          dfuLong32 dfPreviousVersionFileNumber, dfPreviousVersionFilePosition;
          const DFSPREVIOUSVERSIONINFO *pDfsPreviousVersionInfo =
            (const DFSPREVIOUSVERSIONINFO *) TagBuf;
          dfPreviousVersionFileNumber =
            ConvertuLongIntelToLong(pDfsPreviousVersionInfo->
                                    dfPreviousVersionFileNumber);
          dfPreviousVersionFilePosition =
            ConvertuLongIntelToLong(pDfsPreviousVersionInfo->
                                    dfPreviousVersionFilePosition);
          if (dfPreviousVersionFileNumber == 1)
            fi.dfPreviousVersion = dfPreviousVersionFilePosition;
        }
      }

      if (fTryFindFileOnDisk || fFillNameOnDisk)
      {
        FileNameOnDisk =
          dfUnicodeCopyConcatAlloc(szDirBaseUse, fi.FileNameOnArchive);
        if (fTryFindFileOnDisk)
        {
          dfSize = GetFileSizeByName(FileNameOnDisk, NULL);
          if (dfSize == FILE_NOT_EXIST)
          {
            if (fVerboseNotFound)
              printf("file %ws not found\n", FileNameOnDisk);
            if (pfComplete != NULL)
              *pfComplete = FALSE;
            DfsFree(FileNameOnDisk);
          }
          else
          {
            fi.FileNameOnDisk = FileNameOnDisk;
          }
        }
        else
          fi.FileNameOnDisk = FileNameOnDisk;
        ConvertFileNameAndPath(fi.FileNameOnArchive, NULL, 0, FALSE);
      }
      //printf("add %ws,%ws\n",fi.FileNameOnArchive,fi.FileNameOnDisk);
      if (!AddItemToFileSet(pfs, &fi, 1))
      {
        dfError = DFS_ERROR_MEMORY_ERROR;
        break;
      }
    }
  }
  DfsFree(szDirBaseUse);
  if (pDirInfo != NULL)
    FreeDirectoryInfo(&pDirInfo);
  return dfError;
}
