//#include <windows. h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "zlib.h"
#include "difbasic.h"
#include "DfsTlTyp.h"
#include "difstool.h"
#include "DfsTagDf.h"
#include "DfsTagMg.h"

#include "DfsTagBlockFloatEnd.h"



BOOL
TestReadValue(DFTAGLIST DfsTagList, dfuLong32 TagNumber, dfuLong32 valueExpected)
{
  BOOL fResult = FALSE;
  dfuLong32 value;

  if (GetTaguLong(DfsTagList, TagNumber, &value))
  {
    fResult = (value == valueExpected);
    printf("%u value : %u (%u expected) : %s\n", TagNumber,
           value, valueExpected, fResult ? "OK" : "BAD");
  }
  else
    printf("%u value not found !! \n", TagNumber);
  return fResult;
}


void TestPatchMainSimple()
{
  dfvoidp ptrTag = NULL;
  dfuLong32 dfuSizeTagStruct = 0;
  {
    dfuLong32Intel dfuSize;
    // Build the Tag List
    DFTAGLIST DfsTagList;

    DfsTagList = AllocNewTagList();

    AddTag(DfsTagList, DFSTAG_FILENAME, "f.txt", 6);
    //RemoveTag(DfsTagList,DFSTAG_FILENAME);


    if (!AddTag(DfsTagList, DFSTAG_FILENAME, "file.txt", 9))
      printf("Error AddTag 1\n");

    AddTaguLong(DfsTagList, 7662, 66655588);

    dfuSize = ConvertuLongToLongIntel(587);
    if (!AddTag(DfsTagList, DFSTAG_BASEPATCH, &dfuSize, sizeof(dfuSize)))
      printf("Error AddTag 2\n");

    AddTaguLong(DfsTagList, 6661, 1492);
    AddTaguLong(DfsTagList, 6660, 2001);
    //RemoveTag(DfsTagList,6660);
    AddTaguLong(DfsTagList, 6660, 2003);
    //RemoveTag(DfsTagList,6660);
    //RemoveTag(DfsTagList,6660);
    AddTaguLong(DfsTagList, 6660, 2002);
    AddTaguLong(DfsTagList, 6662, 12345678);

    if (!EndBuildTagList(DfsTagList, &ptrTag, &dfuSizeTagStruct, TRUE))
      printf("Error EndBuildTag\n");
    else
      printf("size of packed (building) structure is %d\n", dfuSizeTagStruct);
  }

        /***********************************************************************/

  {
    dfvoidp ptrTagBis = NULL;
    DFTAGLIST DfsTagList;
    dfuLong32 dfuTagListPackedSize;

    ptrTagBis = DfsMalloc(dfuSizeTagStruct);
    DfsMemcpy(ptrTagBis, ptrTag, dfuSizeTagStruct);

    FreeTagPtr(ptrTag);

    DfsTagList = ReadTagList(ptrTagBis, &dfuTagListPackedSize);
    DfsFree(ptrTagBis);
    printf("size of packed structure is %d\n", dfuTagListPackedSize);

    {
      dfvoidp pTagBuf = NULL;
      dfuLong32 pTagSize = 0;
      if (GetTag(DfsTagList, DFSTAG_BASEPATCH, &pTagBuf, &pTagSize))
      {
        dfuLong32 dfuSize = ConvertuLongIntelToLong(*(dfuLong32Intel *) pTagBuf);
        printf("DFSTAG_BASEPATCH : %lu\n", (unsigned long)dfuSize);
      }
      else
      {
        printf("Error : DFSTAG_BASEPATCH not found\n");
      }
    }

    {
      dfvoidp pTagBuf = NULL;
      dfuLong32 pTagSize = 0;
      if (GetTag(DfsTagList, DFSTAG_FILENAME, &pTagBuf, &pTagSize))
      {
        printf("FileName = '%s'\n", (const char*)pTagBuf);
      }
      else
      {
        printf("Error : DFSTAG_FILENAME not found\n");
      }
    }

    {
      dfvoidp pTagBuf = NULL;
      dfuLong32 pTagSize = 0;

      if (GetTag(DfsTagList, DFSTAG_DATE, &pTagBuf, &pTagSize))
      {
        printf("Error : DFSTAG_DATE found\n");
      }
      else
      {
        printf("Normal : DFSTAG_DATE not found\n");
      }

      TestReadValue(DfsTagList, 7662, 66655588);
      TestReadValue(DfsTagList, 6661, 1492);
      TestReadValue(DfsTagList, 6660, 2002);

      AddTaguLong(DfsTagList, 5127, 20022009);

      TestReadValue(DfsTagList, 6662, 12345678);

      TestReadValue(DfsTagList, 5127, 20022009);

    }

    if (!CloseTagList(DfsTagList))
      printf("Error CloseTagList\n");
  }


}



/************************/


BOOL
AddTagFloat(DFTAGBLOCKFLOAT TagList, dfuLong32 TagNumber, dfvoidpc TagBuf, dfuLong32 TagSize)
{
    BOOL fRet=TRUE;
    fRet = AddTagBlockFloat(TagList,0,0,TagNumber,TagBuf,TagSize);
    fRet = fRet && AddTagBlockFloat(TagList,0,4,TagNumber,TagBuf,TagSize);
    fRet = fRet && AddTagBlockFloat(TagList,1,2,TagNumber,TagBuf,TagSize);
    fRet = fRet && AddTagBlockFloat(TagList,0,1,TagNumber,TagBuf,TagSize);
    fRet = fRet && AddTagBlockFloat(TagList,7,1,TagNumber,TagBuf,TagSize);
    fRet = fRet && AddTagBlockFloat(TagList,5,1,TagNumber,TagBuf,TagSize);
    fRet = fRet && AddTagBlockFloat(TagList,1,1,TagNumber,TagBuf,TagSize);
    fRet = fRet && AddTagBlockFloat(TagList,3,TagNumber,TagNumber,TagBuf,TagSize);
    return fRet;
}

BOOL
AddTaguLongFloat(DFTAGBLOCKFLOAT TagList, dfuLong32 TagNumber, dfuLong32 value)
{
    BOOL fRet=TRUE;
    fRet = AddTaguLongBlockFloat(TagList,0,0,TagNumber,value);
    fRet = fRet && AddTaguLongBlockFloat(TagList,0,4,TagNumber,value);
    fRet = fRet && AddTaguLongBlockFloat(TagList,1,2,TagNumber,value);
    fRet = fRet && AddTaguLongBlockFloat(TagList,0,1,TagNumber,value);
    fRet = fRet && AddTaguLongBlockFloat(TagList,1,1,TagNumber,value);
    fRet = fRet && AddTaguLongBlockFloat(TagList,3,TagNumber,TagNumber,value);
    return fRet;
}

BOOL
GetTagFloat(DFTAGBLOCKFLOAT TagList, dfuLong32 TagNumber, dfvoidp * pTagBuf,
       dfuLong32 * pTagSize)
{
    return GetTagBlockFloat(TagList,3,TagNumber,TagNumber,pTagBuf,pTagSize);
}

BOOL
TestReadValueFloat(DFTAGBLOCKFLOAT DfsTagList, dfuLong32 TagNumber, dfuLong32 valueExpected)
{
  BOOL fResult = FALSE;
  dfuLong32 value;

  if (GetTaguLongBlockFloat(DfsTagList, 0,1, TagNumber, &value))
  {
    fResult = (value == valueExpected);
    printf("%u value : %u (%u expected) : %s\n", TagNumber,
           value, valueExpected, fResult ? "OK" : "BAD");
  }
  else
    printf("%u value not found !! \n", TagNumber);
  return fResult;
}


void TestPatchMain()
{
  dfvoidp ptrTag = NULL;
  dfuLong32 i=0;
  dfuLong32 dfuSizeTagStruct = 0;

  TestPatchMainSimple();
  printf("test simple done ***************************************\n");
  {
    dfuLong32Intel dfuSize;
    // Build the Tag List
    DFTAGBLOCKFLOAT DfsTagList;

    DfsTagList = BuildEmptyBlockFloat();


        for (i=0;i<1200;i++)
            AddTaguLongBlockFloat(DfsTagList,40,i+10,7000,i+100);

    AddTagFloat(DfsTagList, DFSTAG_FILENAME, "f.txt", 6);
    //RemoveTag(DfsTagList,DFSTAG_FILENAME);


    if (!AddTagFloat(DfsTagList, DFSTAG_FILENAME, "file.txt", 9))
      printf("Error AddTag 1\n");

    AddTaguLongFloat(DfsTagList, 7662, 66655588);

    dfuSize = ConvertuLongToLongIntel(587);
    if (!AddTagFloat(DfsTagList, DFSTAG_BASEPATCH, &dfuSize, sizeof(dfuSize)))
      printf("Error AddTag 2\n");

    AddTaguLongFloat(DfsTagList, 6661, 1492);
    AddTaguLongFloat(DfsTagList, 6660, 2001);
    //RemoveTag(DfsTagList,6660);
    AddTaguLongFloat(DfsTagList, 6660, 2003);
    //RemoveTag(DfsTagList,6660);
    //RemoveTag(DfsTagList,6660);
    AddTaguLongFloat(DfsTagList, 6660, 2002);
    AddTaguLongFloat(DfsTagList, 6662, 12345678);



        AddTaguLongBlockFloat(DfsTagList,50,1,7000,i+100);
        AddTaguLongBlockFloat(DfsTagList,50,2,7000,i+100);
        AddTaguLongBlockFloat(DfsTagList,50,3,7000,i+100);
        AddTaguLongBlockFloat(DfsTagList,50,4,7000,i+100);
        AddTaguLongBlockFloat(DfsTagList,50,5,7000,i+100);

/*
    for (i=0;i<5;i++)
        AddTaguLongBlockFloat(DfsTagList,0,i+10,7000,i+100);
        */
    AddTaguLongBlockFloat(DfsTagList,0,10,7000,100);
    for (i=5;i>0;i--)
        AddTaguLongBlockFloat(DfsTagList,0,i+10,7000,i+100);


    if (!FlushTagBlockFloat(DfsTagList, &ptrTag, &dfuSizeTagStruct, TRUE))
      printf("Error EndBuildTag\n");
    else
    {
      printf("size of packed (building) structure is %d\n", dfuSizeTagStruct);
    }
    CloseDfTagBlockFloat(DfsTagList);
  }

        /***********************************************************************/

  {
    dfvoidp ptrTagBis = NULL;
    DFTAGBLOCKFLOAT DfsTagList;
    dfuLong32 dfuTagListPackedSize=0;

    ptrTagBis = DfsMalloc(dfuSizeTagStruct);
    DfsMemcpy(ptrTagBis, ptrTag, dfuSizeTagStruct);

    FreeTagPtr(ptrTag);

    DfsTagList = ReadDfTagBlockFloat(ptrTagBis, &dfuTagListPackedSize);
    DfsFree(ptrTagBis);
    printf("size of packed structure is %d\n", dfuTagListPackedSize);

    {
      dfvoidp pTagBuf = NULL;
      dfuLong32 pTagSize = 0;
      if (GetTagFloat(DfsTagList, DFSTAG_BASEPATCH, &pTagBuf, &pTagSize))
      {
        dfuLong32 dfuSize = ConvertuLongIntelToLong(*(dfuLong32Intel *) pTagBuf);
        printf("DFSTAG_BASEPATCH : %lu\n", (unsigned long)dfuSize);
      }
      else
      {
        printf("Error : DFSTAG_BASEPATCH not found\n");
      }
    }

    {
      dfvoidp pTagBuf = NULL;
      dfuLong32 pTagSize = 0;
      if (GetTagFloat(DfsTagList, DFSTAG_FILENAME, &pTagBuf, &pTagSize))
      {
        printf("FileName = '%s'\n", (const char*)pTagBuf);
      }
      else
      {
        printf("Error : DFSTAG_FILENAME not found\n");
      }
    }

    {
      dfvoidp pTagBuf = NULL;
      dfuLong32 pTagSize = 0;

      if (GetTagFloat(DfsTagList, DFSTAG_DATE, &pTagBuf, &pTagSize))
      {
        printf("Error : DFSTAG_DATE found\n");
      }
      else
      {
        printf("Normal : DFSTAG_DATE not found\n");
      }

      TestReadValueFloat(DfsTagList, 7662, 66655588);
      TestReadValueFloat(DfsTagList, 6661, 1492);
      TestReadValueFloat(DfsTagList, 6660, 2002);

      AddTaguLongFloat(DfsTagList, 5127, 20022009);

      TestReadValueFloat(DfsTagList, 6662, 12345678);

      TestReadValueFloat(DfsTagList, 5127, 20022009);

    }

    {
        dfuLong32 read;
        for (i=0;i<5;i++)
        {
            read=999;
            GetTaguLongBlockFloat(DfsTagList,0,i+10,7000,&read);
            if (read!=i+100) printf("(%u,%u)",i,read);
        }
    }

    if (!CloseDfTagBlockFloat(DfsTagList))
      printf("Error CloseTagList\n");
  }
  printf("end.\n");


}
