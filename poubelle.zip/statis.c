//#include <windows. h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "difbasic.h"
#include "difstrm.h"
#include "statis.h"


STATIS *InitStatis(dfuLong32 max_value)
{
  STATIS *statis;
  statis = (STATIS *) malloc(sizeof(STATIS));

  if (statis == NULL)
    return NULL;

  statis->tab_value = (dfuLong32*) malloc(sizeof(dfuLong32) * (max_value + 2));
  if (statis->tab_value == NULL)
  {
    free(statis);
    statis = NULL;
  }
  else
  {
    dfuLong32 i;
    for (i = 0; i <= max_value + 1; i++)
      (*((statis->tab_value) + i)) = 0;
    statis->max_value = max_value;
  }
  return statis;
}

void DeleteStatis(STATIS * statis)
{
  free(statis->tab_value);
  free(statis);
}

void AddValue(STATIS * statis, dfuLong32 value)
{
  if (value > statis->max_value)
    (*((statis->tab_value) + (statis->max_value) + 1))++;
  else
    (*((statis->tab_value) + value))++;
}

int WriteStatis(STATIS * statis, const char *filename, const char *title)
{
  int ret = 1;
  FILE *file;
  file = fopen(filename, "wt");
  if (file == NULL)
    ret = 0;
  else
  {
    dfuLong32 i;
    dfuLong32 total = 0;
    fprintf(file, "%s\n", title);
    for (i = 0; i <= statis->max_value; i++)
    {
      fprintf(file, "%d\t%d\n", i, *((statis->tab_value) + i));
      total += *((statis->tab_value) + i);
    }
    fprintf(file, "More\t%d\n",
            *((statis->tab_value) + (statis->max_value) + 1));
    total += *((statis->tab_value) + (statis->max_value) + 1);
    fprintf(file, "Total\t%d\n", total);
    fclose(file);
  }
  return ret;
}

dfuLong32 GetMaxValue(STATIS * statis)
{
  return statis->max_value;
}
