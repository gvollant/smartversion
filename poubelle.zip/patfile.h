
/* to be better after */
#define DSCALLBACK
typedef char charfilename;
typedef dfuShort charwidefilename;
typedef dfvoidp filehandle;
/* end to be better after */

typedef
filehandle(DSCALLBACK * fopen_func)
OF((const charfilename * filename, const char *mode, dfuLong32 number));

     typedef dfuLong32(DSCALLBACK *
                     fread_func) OF((void *buffer, dfuLong32 size,
                                     dfuLong32 count, filehandle stream));
     typedef dfuLong32(DSCALLBACK *
                     fwrite_func) OF((void *buffer, dfuLong32 size,
                                      dfuLong32 count, filehandle stream));

     typedef dfuLong32(DSCALLBACK * ftell_func) OF((filehandle stream));
     typedef int (DSCALLBACK *
                  fseek_func) OF((filehandle stream, dfuLong32 offset, int));

     typedef int (DSCALLBACK * fclose_func) OF((filehandle stream));
     typedef int (DSCALLBACK * fflush_func) OF((filehandle stream));

/***************************************************************************/

     typedef struct
     {
       dfuLong32 size;
       fopen_func open_func;
       fread_func read_func;
       fwrite_func write_func;
       ftell_func tell_func;
       fclose_func close_func;
       fflush_func flush_func;
     }
PARAMDIFFILE;
//typedef dfuLong32 fopen

//
/*
For reading :
Get Size,
Open For Read (Sequentially or not),
Get FMIO pointer if possible,
read,seek
close


For writting
Pehaps Set Size,
Get FMIO if possible
write (seek ?)
close
*/


/***************************************************************************/

DECLARE_DFHANDLE(DIFFILE);



     typedef struct
     {
       dfuLong32 dfBaseNoDir;
       dfuLong32 dfBaseNoFile;
       dfuLong32 dfBeginPos;
       dfuLong32 dfEndPos;
     }
BASEOFFILE;

/*

*/

     DIFFILE CreateDifFile OF((const charfilename * filename,
                               dfuLong32 size_volume,
                               const PARAMDIFFILE * paramDifFile,
                               dfuLong32 difConfig));

/* mode : patch old to new (with or without old), new insert and new to old */
     DIFFILE OpenDifFile OF((const charfilename * filename, dfuLong32 mode));

/* modedir : reference (only crc), insert (new file full), patch*/
/* we will add compression speed */
     dfuLong32 BeginAddDirectory
       OF((DIFFILE diffile, dfuLong32 modeDir, dfuLong32 * dir_number));

/* we will add stuff for CRC of serial */
/* we can add after option to add from memory the new file*/
/* we must separate info on local and info to retrieve file on disk (for tree, date...)*/

// bad: dfuLong32 AddFileInDirectory OF((DIFFILE diffile,const charfilename* filetoinsert)); */

// BeginAddFile (nom, date/heure, array of BASEOFFILE)
//

     dfuLong32 CloseAddDirectory OF((DIFFILE diffile, dfuLong32 modeDir));


/********/
/* read func */
/****************
- We need known the mode of file
- enumerate dir
- enumerate file in dir, and retrieve content of the file (with previous)
*/
