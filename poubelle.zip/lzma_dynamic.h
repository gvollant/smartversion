// lzma_dynamic.h
//

#ifndef LZMA_DYNAMIC_H
#define LZMA_DYNAMIC_H 1

#ifdef __cplusplus
extern "C" {
#endif

//
#include "lzma.h"
int dynamic_lzma_lib_load();

lzma_ret dynamic_lzma_stream_decoder(
		lzma_stream *strm, uint64_t memlimit, uint32_t flags);

lzma_ret dynamic_lzma_easy_encoder(
		lzma_stream *strm, uint32_t preset, lzma_check check);

void dynamic_lzma_end(lzma_stream *strm);


lzma_ret dynamic_lzma_code(lzma_stream *strm, lzma_action action);


#ifdef __cplusplus
}
#endif

#endif
