typedef TSTHUFOUT;


TSTHUFOUT *InitHufOut();
void write_byte(TSTHUFOUT * tsthuf, int c);
unsigned long CloseHufOut(TSTHUFOUT * tsthuf);
void IncBits(TSTHUFOUT * tsthuf, int nb);
