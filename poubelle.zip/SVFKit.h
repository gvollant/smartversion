// SVFKit.h

/*
 - opening SVF
 - error handling get 
 - get info : kind, number of version
 - get version info (number of file)
 - get file info

 - extract a version

 - create a version subset, then extract it

 - create an insert fileset, then insert it

*/
