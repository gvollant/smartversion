//

#ifndef _SMART_VERSION_BUILDER_H
#define _SMART_VERSION_BUILDER_H  1

#include "SmartVersionBase.h"

#define SMV_OPEN_READ       0x00001
#define SMV_OPEN_READWRITE  0x00002
#define SMV_OPEN_CREATE     0x00004


smv_file* smv_open(const char* file_name, long options);

smv_file* smv_open_memory(const void*, size_t, long options);


#endif
