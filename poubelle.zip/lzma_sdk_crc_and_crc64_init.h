

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int check_lzma_sdk_crc_init();
    
    
#ifdef __cplusplus
}
#endif /* __cplusplus */