/*
 * This sourcefile wrap_memcpy.cpp (which can be renamed wrap_memcpy.c for a pure C project)
 *  solves the problem described in page
 *    http://www.win.tue.nl/~aeb/linux/misc/gcc-semibug.html
 *    http://article.gmane.org/gmane.comp.lib.glibc.alpha/15278
 *
 * In a few word, on amd64/x64 targent, a modification then revert in GlibC prevent
 *  compile with GCC/G++ compiler from recent Linux distribution (Ubuntu 14.04 or newer, by example)
 *  then run the executable on Linux distribution with old GLibC (like Debian 7.5 which contain GLibC 2.13),
 *  because this executable will search GlibC 2.14 or newer.
 *
 * A first option is compile with -static (use no dynamic library, but if you application uses
 * some DNS function (getaddrinfo, gethostbyname), you'll have compatibility problem, see:
 *    https://stackoverflow.com/questions/2725255/create-statically-linked-binary-that-uses-getaddrinfo
 *    https://stackoverflow.com/questions/15165306/compile-a-static-binary-which-code-there-a-function-gethostbyname
 *
 * The workaround in these page is not compatible with -flto (link time optimization) option:
 *    https://stackoverflow.com/questions/8823267/linking-against-older-symbol-version-in-a-so-file
 *    https://stackoverflow.com/questions/36461555/is-it-possible-to-statically-link-libstdc-and-wrap-memcpy
 *    https://gist.github.com/nicky-zs/7541169
 *
 * The solution is calling memmove. memove does exactly the same jobs than memcpy.
 * The only difference is when src and dest zone overlap, memmove is safe and
 * memcpy is unpredictable.
 * So we can safely always call memmove instead memcpy
 *
 * In a few word:
 *   add this file in your makefile or projects, and compile your application on modern Linux
 *     distribution with modern GCC/G++ with option when compile:
 *        -DCOMPILE_WRAP_MEMCPY_AS_MEMMOVE
 *      and when link:
 *        -static-libgcc -static-libstdc++ -Wl,--wrap=memcpy
 *
 *
 * Note: There is another problem using compiler GCC/G++ 7.2 from Ubuntu 17.10
 *  which search __fdelt_chk from GLibC 2.15, see https://github.com/bitcoin/bitcoin/issues/3803
 * We can remove this dependency by compile with option
 *    -U_FORTIFY_SOURCE -D_FORTIFY_SOURCE=0
 *
 * Useful Linux command to check dependency:
 *    readelf -a <executable> | grep "GLIBC_2.1"
 *    nm -D <executable>
 *    ldd <executable>
 *    ldd -v <executable>
 *
 */

/*
#if defined( __GNUC__ )  &&  defined( __LP64__ )  &&  __LP64__ >= 1  && \
(_GNUC__ >= 5  ||  (__GNUC__ == 4  &&  __GNUC_MINOR__ >= 7))  &&  \
(defined( __x86_64__ )  ||  defined( __i386__ )  ||\
defined( __i486__ )  ||  defined( __i586__ )  ||  defined( __i686__ ))
*/


#if defined( __GNUC__ )  &&  defined( __LP64__ )  &&  __LP64__ >= 1  && \
(defined( __x86_64__ )  ||  defined( __i386__ )  ||\
defined( __i486__ )  ||  defined( __i586__ )  ||  defined( __i686__ ))

#if defined(COMPILE_WRAP_MEMCPY_AS_MEMMOVE)

#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

void *__wrap_memcpy(void *dest, const void *src, size_t n)
{
    return memmove(dest, src, n);
}
/* below the other solution, which seem not compatible with -flto */
/*
void *__memcpy_glibc_2_2_5(void *, const void *, size_t);

asm(".symver __memcpy_glibc_2_2_5, memcpy@GLIBC_2.2.5");
void *__wrap_memcpy(void *dest, const void *src, size_t n)
{
    return __memcpy_glibc_2_2_5(dest, src, n);
}
*/
/*
__asm__(".symver memcpy, memcpy@GLIBC_2.2.5");

void *__wrap_memcpy(void *dest, const void *src, size_t n)
{
    return memcpy(dest, src, n);
}
*/
#ifdef __cplusplus
}
#endif

#endif
#endif
