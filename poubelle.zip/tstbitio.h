typedef struct
{
  long countbit;
}
BIT_FILE;

//void          OutputBit( BIT_FILE *bit_file, int bit );
void OutputBits(BIT_FILE * bit_file, unsigned long code, int count);
int InputBit(BIT_FILE * bit_file);
unsigned long InputBits(BIT_FILE * bit_file, int bit_count);
