#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "difbasic.h"
#include "difstrm.h"
#include "patfile.h"
