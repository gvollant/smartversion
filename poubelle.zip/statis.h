#if (defined(MSDOS) || defined(_WINDOWS) || defined(WIN32))  && !defined(STDC)
#  define STDC
#endif
#if defined(__STDC__) || defined(__cplusplus) || defined(__OS2__)
#  ifndef STDC
#    define STDC
#  endif
#endif

#ifndef OF
#  ifdef STDC
#    define OF(args)  args
#  else
#    define OF(args)  ()
#  endif
#endif

#ifndef BASIC_INT_TYPE_DEFINED
#define BASIC_INT_TYPE_DEFINED


typedef unsigned long dfuLong32;
typedef void *dfvoidp;
typedef unsigned char dfbyte;
typedef dfbyte *dfbytep;
#endif

typedef struct
{
  dfuLong32* tab_value;
  dfuLong32 max_value;
}
STATIS;

STATIS *InitStatis OF((dfuLong32 max_value));
void DeleteStatis OF((STATIS * statis));
void AddValue OF((STATIS * statis, dfuLong32 value));
int WriteStatis OF((STATIS * statis, const char *fn, const char *title));
dfuLong32 GetMaxValue OF((STATIS * statis));
