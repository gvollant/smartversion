#define MSGOUTTEST

#if defined(_DEBUG) && defined(MSGOUTTEST)
//#include <windows.h>
#endif

#include <shlobj.h>
#include <stdio.h>



#include "difbasic.h"

#include "DfsTlTyp.h"
#include "difstool.h"
#include "DfsStruc.h"
#include "DfsTagDf.h"
#include "DfsTagMg.h"
#include "DfsTagBlockFloatEnd.h"

#include "DfsIntf.h"

#include "DfsSet.h"
#include "DfsWrSet.h"
#include "DfsRdSet.h"
//#include "DfsCdLin.h"
#include "ArrayTl.h"



#include "DfsIoHlp.h"

#include "zlib.h"
#include "zip.h"



#include "DirSet.h"
#include "DoExtracting.h"
#include "ReMixDfs.h"
#include "FileRefCounter.h"

/* #define _TRYACCELERATE */

/* dfConstructionInfo contain the number of file in previous version from which
       we made patch, of one of these constant : */

#define FIODI_CONSTR_JOKER_BASE     ((dfuLong32)(0xffffff00UL))

/* for file stored only as reference, with CRC (in first version) :*/
#define FIODI_CONSTR_REFERENCE      ((dfuLong32)(0xffffff01UL))

/* for file stored with content, uncompressed or compressed :*/
#define FIODI_CONSTR_NEW            ((dfuLong32)(0xffffff02UL))


/* dfParameter can be a combination of */
#define FIODI_PARAM_PATCH_MODIFED   ((dfuLong32)0x00000001)
#define FIODI_PARAM_PATCH_IDENTICAL ((dfuLong32)0x00000002)

/* FIODI_PARAM_PATCH_MASK is for do a OR (|) test on patch */
#define FIODI_PARAM_PATCH_MASK      ((dfuLong32)0x00000003)

#define FIODI_PARAM_REFERENCE       ((dfuLong32)0x00000004)
#define FIODI_PARAM_NEW             ((dfuLong32)0x00000008)

#define FIODI_PARAM_STOREINFO_MASK  ((dfuLong32)0x000000ff)

/* are filled when we select the file we want extract */
#define FIODI_NEEDED_FOR_EXTRACTING         ((dfuLong32)0x00010000)
#define FIODI_NEEDED_FOR_BLDNEWDFS_TARGET   ((dfuLong32)0x00020000)
#define FIODI_NEEDED_FOR_BLDNEWDFS_ORIGIN   ((dfuLong32)0x00040000)
#define FIODI_NEEDED_MASK                   ((dfuLong32)0x00070000)

typedef struct
{
    dfuLong32 dfConstructionInfo;
    dfuLong32 dfParameter;
    dfuLong32 dfStorageStatus; /* the DFSTAG_STORAGESTATUS tag value (method) */
} FILE_IN_OLD_DFS_INFO;

typedef struct
{
    dfuLong32 dfNbFile;
    FILE_IN_OLD_DFS_INFO* pfiodi;
} DIR_IN_OLD_DFS_INFO;

/*******************************************************************/



typedef struct
{
    /* dfOldDfsFileItem contain the item of the file in the Old DFS
       (the number stored in old DFS file),
       or FINDI_PREVDFS_FILEADDED for an added file */
    dfuLong32 dfOldDfsFileItem;
    dfuLong32 dfBldParameter;


    /* dfPreviousVersionItemInOldSvf contain the item of previous version, in the
       previous directory WE COPY of old DFS or FINDI_PREVVERINNEWDFS_FILEADDED */
    dfuLong32 dfPreviousVersionItemInOldSvf;

    /* dfPreviousVersionItemInNewSvf contain the item of previous version, in the
       previous directory of new DFS, for store in the directory we will build */
    dfuLong32 dfPreviousVersionItemInNewSvf;

    /* location of previous version in previous DFS (useful for REBUILD PATCH) */
    //dfuLong32 dfOldDfsPreviousDirLocation;
    //dfuLong32 dfOldDfsPreviousFileLocation;

    /* if we copy the raw compressed stream (FINDI_PARAM_MASK_RAWCOPY), location of the stream */
    dfuLong32 dfOldDfsRawCopyDirLocation;
    dfuLong32 dfOldDfsRawCopyFileLocation;
    const FILETOADD_REMIX * pftaPreviousItem;
    const FILETOADD_REMIX * pfta;
} FILE_IN_NEW_DFS_INFO;


#define FINDI_PREVDFS_FILEADDED         ((dfuLong32)(0xffffffffUL))

#define FINDI_PREVVERINNEWDFS_FILEADDED ((dfuLong32)(0xffffffffUL))

#define FINDI_PREVVERINOLDDFS_FILEADDED ((dfuLong32)(0xffffffffUL))

/* dfBldParameter is combination of*/
/* 1: we select the kind and construction method */
#define FINDI_PARAM_REFERENCE       ((dfuLong32)0x00000004)

#define FINDI_PARAM_NEW             ((dfuLong32)0x00000008)
#define FINDI_PARAM_NEW_RAWCOPY     ((dfuLong32)0x00000018)
#define FINDI_PARAM_NEW_RECOMPRESS  ((dfuLong32)0x00000028)

#define FINDI_PARAM_PATCH           ((dfuLong32)0x00000001)
#define FINDI_PARAM_PATCH_RAWCOPY   ((dfuLong32)0x00000011)
#define FINDI_PARAM_PATCH_REBUILD   ((dfuLong32)0x00000021)
#define FINDI_PARAM_PATCH_MASK      ((dfuLong32)0x00000003)

#define FINDI_PARAM_PATCH_IDENTICAL ((dfuLong32)0x00000002)

#define FINDI_PARAM_MASK_RAWCOPY    ((dfuLong32)0x00000010)
#define FINDI_PARAM_MASK_REBUILD    ((dfuLong32)0x00000020)

#define FINDI_PARAM_MASK_BUILDMETH  ((dfuLong32)0x000000ff)


#define AFTER_LAST_DIRECTORY        ((dfuLong32)(0xffffffffUL))

typedef struct
{
    dfuLong32 dfNbFile;
    dfuLong32 dfNbFileReuse ;
    dfuLong32 dfNbFileAdding;

    dfuLong32 dfNumDirVersionOldSvf ;
    FILE_IN_NEW_DFS_INFO* pfindi;
} DIR_IN_NEW_DFS_INFO;

/****************************************************************************/
/******* TO BE DELETED CODE FROM NOW */
/****************************************************************************/

BOOL DoInsertDirectoryFileSet2_(DFSFILE DfsFileWrite,dfuLong32 dfTypeDir,
                              FILESET * pfsOrg, FILESET * pfsDest,

                              dfuLong32 dfNbDirDfsRead,const PDIRINFO* pDirInfo,
                              const DIR_IN_OLD_DFS_INFO* pdiodi,
                              const DIR_IN_NEW_DFS_INFO* pdindi_,

                              dfwcharpc dfwVersionName,dfwcharpc dfwVersionComment,
                              const COMPRESSIONPARAM* pCprParam,
                              tProgressCallBack pProgressCallBack,dfvoidp dfUserPtr)
{
    BOOL fRet=TRUE;
    FILETOADD * pFileToAdd;
    dfuLong32 dfNumDirVersionOldSvf;
    dfuLong32 i;
    const DIR_IN_NEW_DFS_INFO* pdindicur = pdindi_;
    pFileToAdd=(FILETOADD *)DfsMalloc((pfsDest->dfNbFileItem+1)*sizeof(FILETOADD));
    if (pFileToAdd==NULL)
        return FALSE;

    dfNumDirVersionOldSvf = pdindicur->dfNumDirVersionOldSvf;

    for (i=0;i<pdindicur->dfNbFile;i++)
    {
        //dfuLong32 j;
        FILE_IN_NEW_DFS_INFO* pfindicur=(pdindicur->pfindi)+i;
        dfuLong32 dfBuildMethod = pfindicur->dfBldParameter & FINDI_PARAM_MASK_BUILDMETH;
        dfuLong32 dfPreviousVersionItemInOldSvf = pfindicur->dfPreviousVersionItemInOldSvf ;
        const FILEINDIRINFO* pFileInDirInfoOldDfs = NULL;

        if (dfPreviousVersionItemInOldSvf != FINDI_PREVVERINNEWDFS_FILEADDED)
            pFileInDirInfoOldDfs =
                (((*(pDirInfo+(pdindicur->dfNumDirVersionOldSvf)))->pFileInDirInfo) +
                  (dfPreviousVersionItemInOldSvf));

        (pFileToAdd+i)->fIgnore=FALSE;
        (pFileToAdd+i)->fForceDate = FALSE;
        (pFileToAdd+i)->fAddNewTag = FALSE;
        (pFileToAdd+i)->pReserved = NULL;
        (pFileToAdd+i)->filename_tostore = NULL;
        (pFileToAdd+i)->filename_ondisk = NULL;

        if (i<pfsDest->dfNbFileItem)
        {
            (pFileToAdd+i)->fAddNewTag = ((pfsDest->pFileItem)+i)->fAddNewTag;
            (pFileToAdd+i)->pReserved = ((pfsDest->pFileItem)+i)->pReserved;
            (pFileToAdd+i)->filename_tostore = ((pfsDest->pFileItem)+i)->FileNameOnArchive;
            (pFileToAdd+i)->filename_ondisk = ((pfsDest->pFileItem)+i)->FileNameOnDisk;
        }
        (pFileToAdd+i)->fWritingRaw = FALSE;

        (pFileToAdd+i)->fForceRecopyPrevious = FALSE;
        (pFileToAdd+i)->dfForceRecopyOrRawCopySize = 0;
        (pFileToAdd+i)->dfForceRecopyOrRawCopyCrc32 = 0;


        (pFileToAdd+i)->dfPreviousVersionFilePosition=VALUE_UNKNOWN;
        (pFileToAdd+i)->filename_prevversionondisk=NULL;

        if (dfBuildMethod == FINDI_PARAM_PATCH_IDENTICAL)
            (pFileToAdd+i)->fForceRecopyPrevious = TRUE;

        if ((dfBuildMethod == FINDI_PARAM_PATCH_RAWCOPY) ||
            (dfBuildMethod == FINDI_PARAM_NEW_RAWCOPY))
        {
            FILEINDIRINFO* pFileInDirInfoCopy =
                (((*(pDirInfo+(pfindicur->dfOldDfsRawCopyDirLocation)))->pFileInDirInfo) +
                  (pfindicur->dfOldDfsRawCopyFileLocation));
            (pFileToAdd+i)->fWritingRaw = TRUE;
            (pFileToAdd+i)->dfFileStatusForRaw =
                (((pdiodi + pfindicur->dfOldDfsRawCopyDirLocation) ->pfiodi) +
                       pfindicur->dfOldDfsRawCopyFileLocation)->dfStorageStatus;
        }

        if (pFileInDirInfoOldDfs!=NULL)
        {
            (pFileToAdd+i)->filename_tostore = pFileInDirInfoOldDfs->FileName;
            ConvertDfsTmToDfsInfoDate(&pFileInDirInfoOldDfs->dfsTm,&((pFileToAdd+i)->dfsInfoDate));
            (pFileToAdd+i)->fForceDate = TRUE;
        }

        if ((pFileInDirInfoOldDfs==NULL) && (pfindicur->pfta!=NULL))
        {
            (pFileToAdd+i)->filename_tostore = pfindicur->pfta->filename_tostore;
            (pFileToAdd+i)->filename_ondisk =  pfindicur->pfta->filename_ondisk;
        }

        if (((dfBuildMethod == FINDI_PARAM_PATCH_RAWCOPY) ||
             (dfBuildMethod == FINDI_PARAM_NEW_RAWCOPY) ||
             (dfBuildMethod == FINDI_PARAM_PATCH_IDENTICAL)) &&
            (pFileInDirInfoOldDfs!=NULL))
        {
            (pFileToAdd+i)->dfForceRecopyOrRawCopySize = pFileInDirInfoOldDfs->dfSize;
            (pFileToAdd+i)->dfForceRecopyOrRawCopyCrc32 = pFileInDirInfoOldDfs->dfCrc32;
        }

        if (((dfBuildMethod & FINDI_PARAM_PATCH_MASK) != 0) && (pfsOrg!=NULL))
        {

            (pFileToAdd+i)->dfPreviousVersionFilePosition = pfindicur->dfPreviousVersionItemInNewSvf;
            if (dfPreviousVersionItemInOldSvf != FINDI_PREVVERINNEWDFS_FILEADDED)
                (pFileToAdd+i)->filename_prevversionondisk =
                                    ((pfsOrg->pFileItem)+dfPreviousVersionItemInOldSvf)->FileNameOnDisk;
            if (dfPreviousVersionItemInOldSvf == FINDI_PREVVERINNEWDFS_FILEADDED)
            {
                const DIR_IN_NEW_DFS_INFO* pdindicurPrev = pdindicur-1;
                if ((pfindicur->dfPreviousVersionItemInNewSvf) < (pdindicurPrev->dfNbFile))
                {
                  FILE_IN_NEW_DFS_INFO* pfindipref=(pdindicurPrev->pfindi)+(pfindicur->dfPreviousVersionItemInNewSvf);

                  (pFileToAdd+i)->filename_prevversionondisk = pfindipref->pfta->filename_ondisk;
                }
            }

            // TODO : if (dfPreviousVersionItemInOldSvf == FINDI_PREVVERINNEWDFS_FILEADDED)
        }
    }
    if (dfwVersionName==NULL) dfwVersionName=L"";
    fRet = InsertDirectoryinDfsFile(DfsFileWrite,dfTypeDir,
                                    pfsDest->dfNbFileItem,pFileToAdd,
                                    dfwVersionName,dfwVersionComment,
                                    pCprParam,
                                    pProgressCallBack,dfUserPtr) == DFS_SUCCESS;
    DfsFree(pFileToAdd);
    return fRet;
}

BOOL DoReMixDfsBad(DFSFILE DfsFileRead,dfuLong32 dfNbDirDfsRead,PDIRINFO* pDirInfo,
                DFSFILE *pDfsFileWrite,dfwcharpc dfWritingDfsFileName, // BOOL fZipFile,
                BOOL fBaseDirectorySelected,dfuLong32 dfBaseDirNum,dfwcharpc wchBaseDirectory,
                dfuLong32 dfNbVersionRemix, const VERSIONTOADD_REMIX * pVersionRemix,
                BOOL fFirstVersionAsReference,BOOL fReuseOldPatch, // future
                const COMPRESSIONPARAM* pCprParam,
                tSetExtractPosCallBack pSetExtractPosCallBack,dfvoidp dfUserPtr,
                dfuLong32 dwMinProgress,dfuLong32 dwMaxProgress)
{
    DIR_IN_OLD_DFS_INFO* pDiodi = NULL;
    DIR_IN_NEW_DFS_INFO* pDindi = NULL;
    BOOL fBaseNeeded ;
    dfuLong32 dfNumDirOldDfs ;
    dfuLong32 dfNbVersionWritten=0;
    dfuLong32 dfProgressStep = 1;
    dfuLong32 dfProgressStartcurrentStep=0;
    BOOL fRet = TRUE ;
    dfuLong32 dfLastDirExtr,dfDirStartExtr;
    DFSFILE DfsFileWrite = NULL;
    FILESET **ppFileSetCollection=NULL;
    dfuLong32 i;
    BOOL * lpVersionMap = NULL;
    dfwcharpc wchBaseDirExtract = L""; // to modify
    /* Todo : First, checking consistency of parameter */

    if (pDfsFileWrite != NULL)
        *pDfsFileWrite = NULL;

    fBaseNeeded = ((*pDirInfo)->dfTypeDir == TYPEDIR_FILECRCONLY);
    dfNumDirOldDfs = dfNbDirDfsRead;

    if (fRet)
        lpVersionMap = DfsMalloc(sizeof(BOOL) * (dfNbDirDfsRead+1));

    if (lpVersionMap == NULL)
        fRet = FALSE;

    if (fRet)
    {
        dfuLong32 dfPrevVersionMarked;
        for (i=0;i<dfNbDirDfsRead;i++)
            *(lpVersionMap+i)=FALSE;
        for (i=0;i<dfNbVersionRemix;i++)
        {
            dfuLong32 dfVer = (pVersionRemix+i)->dfNumVersionPreviousSvf;
            if (i>0)
                if ((dfVer <= dfPrevVersionMarked) || (dfVer >= dfNbDirDfsRead))
                {
                    fRet=FALSE;
                    break;
                }
            *(lpVersionMap+i) = TRUE;
            dfPrevVersionMarked = dfVer;
        }
    }

    if (fRet)
        pDiodi = BuildDirInOldArray(dfNbDirDfsRead,pDirInfo);

    if (fRet && (pDiodi != NULL))
        pDindi = BuildDirInNewArray(dfNbDirDfsRead,pDiodi,
                                    dfNbVersionRemix,pVersionRemix,
                                    fFirstVersionAsReference);

    if ((pDindi == NULL) || (pDiodi == NULL))
        fRet = FALSE;


    if (fRet)
        fRet = BuildDependecyInOldDfs(dfNbDirDfsRead,pDiodi,dfNbVersionRemix,pDindi);


    /* now the preparation work is done, we do the real work ! */

    dfDirStartExtr = dfBaseDirNum;
    dfLastDirExtr = dfNbDirDfsRead-1; /* can be better : do not extract last version if they are not used */

    if ((dfNbVersionRemix + (1 + dfLastDirExtr - dfDirStartExtr)) > 0)
        dfProgressStep =
        (dwMaxProgress - dwMinProgress) / (dfNbVersionRemix +
                                            (1 + dfLastDirExtr -
                                            dfDirStartExtr));


    /* opening DFSWrite */
    if (fRet)
    {
        DFSFILEINFOPARAM DfsFileParam;

        DfsFileParam.sizeStruct = sizeof(DfsFileParam);
        DfsFileParam.dfStatus = DFS_NEWFILE | DFS_WRITABLE;

        DfsFileParam.filename = dfWritingDfsFileName;

        DfsOpen(DfsFileParam, &DfsFileWrite);
        if (pDfsFileWrite != NULL)
          *pDfsFileWrite = DfsFileWrite;
        if (DfsFileWrite == NULL)
          fRet = FALSE;
    }


    ppFileSetCollection =
        (FILESET **) DfsMalloc((dfLastDirExtr + 1) * (sizeof(FILESET *)));
    for (i = 0; i <= dfLastDirExtr; i++)
        *(ppFileSetCollection + i) = NULL;

    for (i = dfDirStartExtr; i <= dfLastDirExtr; i++)
    {
        BOOL fFirstBase = ((i == dfDirStartExtr) && (fBaseNeeded));
        BOOL fAllIsGood = FALSE;
        FILESET *pfsCur;
        dfuLong32 dfError, dfTypeDir;
        dfError = dfTypeDir = 0;

        pfsCur = (FILESET *) DfsMalloc(sizeof(FILESET));
        *(ppFileSetCollection + i) = pfsCur;

        InitFileSet(pfsCur);

        dfError =
        CreateFileSetForVersionInDirectory(DfsFileRead, pfsCur,
                                            i,
                                            fFirstBase ? wchBaseDirectory :
                                            wchBaseDirExtract, &fAllIsGood,
                                            FALSE, FALSE, fFirstBase, fFirstBase,
                                            &dfTypeDir, TRUE, FALSE);

        if ((dfError != DFS_SUCCESS) || (!fAllIsGood))
        {
          fRet = FALSE;
          break;
        }
    }


    /* free temporary table */


    if (ppFileSetCollection != NULL)
    {
      for (i = dfDirStartExtr; i <= dfLastDirExtr; i++)
        if (*(ppFileSetCollection + i) != NULL)
        {
          FreeFileSet(*(ppFileSetCollection + i), FALSE);
          DfsFree(*(ppFileSetCollection + i));
        }
      DfsFree(ppFileSetCollection);
    }


    //////////////////////////////////////////////////////////////////////
  {
    FILESET *pfsOrg = NULL;
    FILESET *pfsOrgNewDfs = NULL;
    BOOL fOrgNewDfsToDelete = FALSE;
    FILESET *pfsDest = NULL;
    dfuLong32 dfError = DFS_SUCCESS;


    for (i = dfDirStartExtr; (i <= dfLastDirExtr) && fRet; i++)
    {
      BOOL fFileOrgToDelete = TRUE;

      if ((i == dfDirStartExtr) && (fBaseNeeded))
      {
        pfsOrg = *(ppFileSetCollection + dfDirStartExtr);
        *(ppFileSetCollection + dfDirStartExtr) = NULL;

        if (dfError != DFS_SUCCESS)
        {
          fRet = FALSE;
          break;
        }
        fFileOrgToDelete = FALSE;

        //if (*(lpVersionMap + dfDirStartExtr))
        {
          BOOL fInsert;
          PROGRESSCBPARAMEP pcp;
          dfuLong32 dfTypeDir = (fFirstVersionAsReference ?
                               TYPEDIR_FILECRCONLY :
                               TYPEDIR_FILEINSERTING_DEFLATE);

          // dfs ... do build
          //do InsertDirectoryinDfsFile or zip

          pcp.dwMinProgress = dfProgressStartcurrentStep;
          pcp.dwMaxProgress = dfProgressStartcurrentStep + dfProgressStep;

          pcp.pSetExtractPosCallBack = pSetExtractPosCallBack;
          pcp.dfuPtrSetExtractPosCallBack = dfUserPtr;

          pcp.pConfirmBeforeCreatingFile = NULL;
          pcp.dfUserPtrBeforeCreatingFile = NULL;

          fInsert = DoInsertDirectoryFileSet2_(DfsFileWrite, dfTypeDir,
                                             NULL, pfsOrg,

                                             dfNbDirDfsRead,pDirInfo,
                                             pDiodi,pDindi,

                                             /*dfwVersionName */ NULL, NULL,
                                             pCprParam,
                                             ProgressCallBackDoExtracting,
                                             &pcp);


          /* copy DIRECTORY NAME and Comment */
          CopyTagBuf(i,dfNbVersionWritten,DfsFileRead,DfsFileWrite);

          if (!fInsert)
            fRet = FALSE;
          else
            dfNbVersionWritten++;

          pfsOrgNewDfs = pfsOrg;
          fOrgNewDfsToDelete = FALSE;
          dfProgressStartcurrentStep += dfProgressStep;
        }
        i++;
        if (i > dfLastDirExtr)
          break;                /*+++ */
      }
      else
      {
        pfsOrg = pfsDest;       // Get Previous Dest
        if (i > dfDirStartExtr)
          if (*(lpVersionMap + i - 1))
          {
            pfsOrgNewDfs = pfsDest;
            fOrgNewDfsToDelete = TRUE;
          }
      }

/* do build and extract pfsDest */


      pfsDest = *(ppFileSetCollection + i);
      *(ppFileSetCollection + i) = NULL;

      pfsDest->fTempFile = TRUE;


      if (dfError != DFS_SUCCESS)
      {
        fRet = FALSE;
        break;
      }

      {

        PROGRESSCBPARAMEP pcp;
        pcp.dwMinProgress = dfProgressStartcurrentStep;
        pcp.dwMaxProgress = dfProgressStartcurrentStep + dfProgressStep;

        pcp.pSetExtractPosCallBack = pSetExtractPosCallBack;
        pcp.dfuPtrSetExtractPosCallBack = dfUserPtr;
        pcp.pConfirmBeforeCreatingFile = NULL;
        pcp.dfUserPtrBeforeCreatingFile = NULL;

        dfError = ExtractPatch(DfsFileRead, pfsOrg, pfsDest, i,
                               TRUE, FALSE,
                               wchBaseDirExtract,
                               ProgressCallBackDoExtracting, &pcp);
        dfProgressStartcurrentStep += dfProgressStep;
      }

      if ((dfError == DFS_SUCCESS) && (*(lpVersionMap + i)))
      {
        // dfs ... do build
        //do InsertDirectoryinDfsFile or zip
        {
          BOOL fInsert;
          PROGRESSCBPARAMEP pcp;
          dfuLong32 dfTypeDir;

          pcp.dwMinProgress = dfProgressStartcurrentStep;
          pcp.dwMaxProgress = dfProgressStartcurrentStep + dfProgressStep;

          pcp.pSetExtractPosCallBack = pSetExtractPosCallBack;
          pcp.dfuPtrSetExtractPosCallBack = dfUserPtr;
          pcp.pConfirmBeforeCreatingFile = NULL;
          pcp.dfUserPtrBeforeCreatingFile = NULL;

          dfTypeDir = (pfsOrgNewDfs != NULL) ? TYPEDIR_PATCHFROMPREVIOUS :
            (fFirstVersionAsReference ?
             TYPEDIR_FILECRCONLY : TYPEDIR_FILEINSERTING_DEFLATE);

          // dfs ... do build
          //do InsertDirectoryinDfsFile or zip

            fInsert = DoInsertDirectoryFileSet2_(DfsFileWrite, dfTypeDir,
                                             pfsOrgNewDfs, pfsDest,


                                             dfNbDirDfsRead,pDirInfo,
                                             pDiodi,pDindi,


                                             /*dfwVersionName */ NULL, NULL,
                                             pCprParam,
                                             ProgressCallBackDoExtracting,
                                             &pcp);

          CopyTagBuf(i,dfNbVersionWritten,DfsFileRead,DfsFileWrite);

          if (!fInsert)
            fRet = FALSE;
          else
            dfNbVersionWritten++;
          dfProgressStartcurrentStep += dfProgressStep;
        }

        if (pfsOrg == pfsOrgNewDfs)
          pfsOrgNewDfs = NULL;

        if (pfsOrgNewDfs != NULL)
        {
          FreeFileSet(pfsOrgNewDfs, fOrgNewDfsToDelete);
          DfsFree(pfsOrgNewDfs);
          pfsOrgNewDfs = NULL;
        }
      }

      if ((dfError != DFS_SUCCESS))
      {
        fRet = FALSE;
        break;
      }

      if ((pfsOrg != NULL) && (pfsOrg != pfsOrgNewDfs))
      {
        {
          FreeFileSet(pfsOrg, fFileOrgToDelete);
          DfsFree(pfsOrg);
        }
      }
      pfsOrg = NULL;

      //dfProgressStartcurrentStep+=dfProgressStep ;
      if ((fRet) && (dwMaxProgress != 0)
          && (dfLastDirExtr + 1 > dfDirStartExtr))
      {
        dfuLong32 dwNewPos;
        dwNewPos = dfProgressStartcurrentStep;
#ifdef _DEBUG
        OutputDebugString("$");
#endif


        if (pSetExtractPosCallBack != NULL)
          pSetExtractPosCallBack(dwNewPos, 0, dfUserPtr);
      }
    }


    if ((pfsOrgNewDfs != NULL))
    {
      FreeFileSet(pfsOrgNewDfs, fOrgNewDfsToDelete);
      DfsFree(pfsOrgNewDfs);
      if (pfsOrgNewDfs == pfsDest)
        pfsDest = NULL;
      pfsOrgNewDfs = NULL;
    }


    {
      if (pfsDest != NULL)
      {
        FreeFileSet(pfsDest, TRUE);
        DfsFree(pfsDest);
        pfsDest = NULL;
      }
    }


    if (ppFileSetCollection != NULL)
    {
      for (i = dfDirStartExtr; i <= dfLastDirExtr; i++)
        if (*(ppFileSetCollection + i) != NULL)
        {
          FreeFileSet(*(ppFileSetCollection + i), FALSE);
          DfsFree(*(ppFileSetCollection + i));
        }
      DfsFree(ppFileSetCollection);
    }

/*
#if defined(_DEBUG) && defined(MSGTEST)
    if (!fRet)
      if (hwndMain != NULL)
        MessageBox(hwndMain, "We do subgenerating", fRet ? "TRUE" : "FALSE",
                   MB_OK | MB_ICONERROR);
#endif
*/
    if ((fRet) && (dwMaxProgress != 0))
      if (pSetExtractPosCallBack != NULL)
        pSetExtractPosCallBack(dwMaxProgress, 0, dfUserPtr);
    //guiItem.SetProgressPos(dwMaxProgress);
  }

    //////////////////////////////////////////////////////////////////////


    if ((pDfsFileWrite == NULL) && (DfsFileWrite != NULL))
      DfsClose(DfsFileWrite);

    FreeDirInNewArray(pDindi);
    FreeDirInOldArray(pDiodi);
    if (lpVersionMap != NULL)
        DfsFree(lpVersionMap);
    return fRet;
}




//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

BOOL DoInsertDirectoryFileSetPROV(DFSFILE DfsFileWrite,dfuLong32 dfTypeDir,
                              FILESET * pfsOrg, FILESET * pfsDest,
                              dfwcharpc dfwVersionName,dfwcharpc dfwVersionComment,
                              const COMPRESSIONPARAM* pCprParam,
                              tProgressCallBack pProgressCallBack,dfvoidp dfUserPtr)
{
    BOOL fRet=TRUE;
    FILETOADD * pFileToAdd;
    dfuLong32 i;
    pFileToAdd=(FILETOADD *)DfsMalloc((pfsDest->dfNbFileItem+1)*sizeof(FILETOADD));
    if (pFileToAdd==NULL)
        return FALSE;

    for (i=0;i<pfsDest->dfNbFileItem;i++)
    {
        dfuLong32 j;
        (pFileToAdd+i)->fIgnore=FALSE;
        (pFileToAdd+i)->fForceDate = ((pfsDest->pFileItem)+i)->fForceDate;
        (pFileToAdd+i)->fAddNewTag = ((pfsDest->pFileItem)+i)->fAddNewTag;
        (pFileToAdd+i)->dfsInfoDate = ((pfsDest->pFileItem)+i)->dfsInfoDate;
        (pFileToAdd+i)->pReserved = ((pfsDest->pFileItem)+i)->pReserved;
        (pFileToAdd+i)->fWritingRaw = FALSE;

        (pFileToAdd+i)->filename_tostore = ((pfsDest->pFileItem)+i)->FileNameOnArchive;
        (pFileToAdd+i)->filename_ondisk = ((pfsDest->pFileItem)+i)->FileNameOnDisk;
        (pFileToAdd+i)->fForceRecopyPrevious = FALSE;
        (pFileToAdd+i)->dfForceRecopyOrRawCopySize = 0;
        (pFileToAdd+i)->dfForceRecopyOrRawCopyCrc32 = 0;


        (pFileToAdd+i)->dfPreviousVersionFilePosition=VALUE_UNKNOWN;
        (pFileToAdd+i)->filename_prevversionondisk=NULL;

        if (pfsOrg!=NULL)
          for (j=0;j<pfsOrg->dfNbFileItem;j++)
            {
                dfwcharpc dfwFta=(pFileToAdd+i)->filename_tostore;
                dfwcharpc dfwPrevFileName=((pfsOrg->pFileItem)+j)->FileNameOnArchive;

                if (dfUnicodeStrcmpi(dfwPrevFileName,dfwFta)==0)
                {
                    (pFileToAdd+i)->dfPreviousVersionFilePosition = j;
                    (pFileToAdd+i)->filename_prevversionondisk =
                                      ((pfsOrg->pFileItem)+j)->FileNameOnDisk;

                    break;
                }
            }
    }
    if (dfwVersionName==NULL) dfwVersionName=L"";
    fRet = InsertDirectoryinDfsFile(DfsFileWrite,dfTypeDir,
                                    pfsDest->dfNbFileItem,pFileToAdd,
                                    dfwVersionName,dfwVersionComment,
                                    pCprParam,
                                    pProgressCallBack,dfUserPtr) == DFS_SUCCESS;
    DfsFree(pFileToAdd);
    return fRet;
}


BOOL DoGenerateSubDfsPROV(DFSFILE DfsFileRead, /*dfuLong32 dfNbDir, */
                      PDIRINFO * pDirInfo,
                      DFSFILE * pDfsFileWrite, dfwcharpc dfWritingDfsFileName,  /*BOOL fZipFile, */
                      BOOL fBaseDirectorySelected, dfuLong32 dfBaseDirNum,
                      dfwcharpc wchBaseDirectory, dfuLong32 dwNbMapVersionMap,
                      const BOOL * lpVersionMap,
                      BOOL fFirstVersionAsReference,
                      BOOL fReuseOldPatch /* future */ ,
                      const COMPRESSIONPARAM * pCprParam,
                      tSetExtractPosCallBack pSetExtractPosCallBack,
                      dfvoidp dfUserPtr, dfuLong32 dwMinProgress,
                      dfuLong32 dwMaxProgress)
{
  BOOL fBaseOk = FALSE;
  BOOL fBaseNeeded = FALSE;
  BOOL fRet = TRUE;
  dfuLong32 dfDirStartExtr = 0;
  dfuLong32 dfLastDirExtr = 0;
  dfuLong32 dfFirstDirExtr = VALUE_UNKNOWN;
  dfuLong32 dfVersionToWrite = 0;
  dfuLong32 i;
  FILESET **ppFileSetCollection;
  dfwcharpc wchBaseDirExtract = L"";
  DFSFILE DfsFileWrite = NULL;
  dfuLong32 dfProgressStep = 0;
  dfuLong32 dfProgressStartcurrentStep = dwMinProgress;
  dfuLong32 dfNbVersionWritten = 0;
#if defined(_DEBUG) && defined(MSGTEST)
  HWND hWndMain = GetDesktopWindow();
#endif

  if (pDfsFileWrite != NULL)
    *pDfsFileWrite = NULL;



  for (i = 0; i < dwNbMapVersionMap; i++)
    if (*(lpVersionMap + i))
    {
      if (dfFirstDirExtr == VALUE_UNKNOWN)
        dfFirstDirExtr = i;
      dfLastDirExtr = i;
      dfVersionToWrite++;
    }

  if ((dfVersionToWrite + (1 + dfLastDirExtr - dfDirStartExtr)) > 0)
    dfProgressStep =
      (dwMaxProgress - dwMinProgress) / (dfVersionToWrite +
                                         (1 + dfLastDirExtr -
                                          dfDirStartExtr));

  /* return if no dir to extract */
  if (dfFirstDirExtr == VALUE_UNKNOWN)
    return FALSE;

  fBaseNeeded = ((*pDirInfo)->dfTypeDir == TYPEDIR_FILECRCONLY);
  if (fBaseNeeded)
  {
    /* we need dir selected */
    BOOL fBaseOk = FALSE;
    if (fBaseDirectorySelected)
      if (dfBaseDirNum <= dfFirstDirExtr)
      {
        fBaseOk = TRUE;
        dfDirStartExtr = dfBaseDirNum;
      }

    if (!fBaseOk)
    {
      return FALSE;
    }
  }


  {
    DFSFILEINFOPARAM DfsFileParam;

    DfsFileParam.sizeStruct = sizeof(DfsFileParam);
    DfsFileParam.dfStatus = DFS_NEWFILE | DFS_WRITABLE;

    DfsFileParam.filename = dfWritingDfsFileName;

    DfsOpen(DfsFileParam, &DfsFileWrite);
    if (pDfsFileWrite != NULL)
      *pDfsFileWrite = DfsFileWrite;
    if (DfsFileWrite == NULL)
      return FALSE;
  }

  ppFileSetCollection =
    (FILESET **) DfsMalloc((dfLastDirExtr + 1) * (sizeof(FILESET *)));
  for (i = 0; i <= dfLastDirExtr; i++)
    *(ppFileSetCollection + i) = NULL;

  for (i = dfDirStartExtr; i <= dfLastDirExtr; i++)
  {
    BOOL fFirstBase = ((i == dfDirStartExtr) && (fBaseNeeded));
    BOOL fAllIsGood = FALSE;
    FILESET *pfsCur;
    dfuLong32 dfError, dfTypeDir;
    dfError = dfTypeDir = 0;

    pfsCur = (FILESET *) DfsMalloc(sizeof(FILESET));
    *(ppFileSetCollection + i) = pfsCur;

    InitFileSet(pfsCur);

    dfError =
      CreateFileSetForVersionInDirectory(DfsFileRead, pfsCur, i,
                                         fFirstBase ? wchBaseDirectory :
                                         wchBaseDirExtract, &fAllIsGood,
                                         FALSE, FALSE, fFirstBase, fFirstBase,
                                         &dfTypeDir, TRUE, FALSE);

    if ((dfError != DFS_SUCCESS) || (!fAllIsGood))
    {
      fRet = FALSE;
      break;
    }
  }

  {
    FILESET *pfsOrg = NULL;
    FILESET *pfsOrgNewDfs = NULL;
    BOOL fOrgNewDfsToDelete = FALSE;
    FILESET *pfsDest = NULL;
    dfuLong32 dfError = DFS_SUCCESS;


    for (i = dfDirStartExtr; (i <= dfLastDirExtr) && fRet; i++)
    {
      BOOL fFileOrgToDelete = TRUE;

      if ((i == dfDirStartExtr) && (fBaseNeeded))
      {
        pfsOrg = *(ppFileSetCollection + dfDirStartExtr);
        *(ppFileSetCollection + dfDirStartExtr) = NULL;

        if (dfError != DFS_SUCCESS)
        {
          fRet = FALSE;
          break;
        }
        fFileOrgToDelete = FALSE;

        if (*(lpVersionMap + dfDirStartExtr))
        {
          BOOL fInsert;
          PROGRESSCBPARAMEP pcp;
          dfuLong32 dfTypeDir = (fFirstVersionAsReference ?
                               TYPEDIR_FILECRCONLY :
                               TYPEDIR_FILEINSERTING_DEFLATE);

          // dfs ... do build
          //do InsertDirectoryinDfsFile or zip

          pcp.dwMinProgress = dfProgressStartcurrentStep;
          pcp.dwMaxProgress = dfProgressStartcurrentStep + dfProgressStep;

          pcp.pSetExtractPosCallBack = pSetExtractPosCallBack;
          pcp.dfuPtrSetExtractPosCallBack = dfUserPtr;

          pcp.pConfirmBeforeCreatingFile = NULL;
          pcp.dfUserPtrBeforeCreatingFile = NULL;

          fInsert = DoInsertDirectoryFileSetPROV(DfsFileWrite, dfTypeDir,
                                             NULL, pfsOrg,
                                             /*dfwVersionName */ NULL, NULL,
                                             pCprParam,
                                             ProgressCallBackDoExtracting,
                                             &pcp);


          /* copy DIRECTORY NAME and Comment */
          CopyTagBuf(i,dfNbVersionWritten,DfsFileRead,DfsFileWrite);

          if (!fInsert)
            fRet = FALSE;
          else
            dfNbVersionWritten++;

          pfsOrgNewDfs = pfsOrg;
          fOrgNewDfsToDelete = FALSE;
          dfProgressStartcurrentStep += dfProgressStep;
        }
        i++;
        if (i > dfLastDirExtr)
          break;                /*+++ */
      }
      else
      {
        pfsOrg = pfsDest;       // Get Previous Dest
        if (i > dfDirStartExtr)
          if (*(lpVersionMap + i - 1))
          {
            pfsOrgNewDfs = pfsDest;
            fOrgNewDfsToDelete = TRUE;
          }
      }

/* do build and extract pfsDest */


      pfsDest = *(ppFileSetCollection + i);
      *(ppFileSetCollection + i) = NULL;

      pfsDest->fTempFile = TRUE;


      if (dfError != DFS_SUCCESS)
      {
        fRet = FALSE;
        break;
      }

      {

        PROGRESSCBPARAMEP pcp;
        pcp.dwMinProgress = dfProgressStartcurrentStep;
        pcp.dwMaxProgress = dfProgressStartcurrentStep + dfProgressStep;

        pcp.pSetExtractPosCallBack = pSetExtractPosCallBack;
        pcp.dfuPtrSetExtractPosCallBack = dfUserPtr;
        pcp.pConfirmBeforeCreatingFile = NULL;
        pcp.dfUserPtrBeforeCreatingFile = NULL;

        dfError = ExtractPatch(DfsFileRead, pfsOrg, pfsDest, i,
                               TRUE, FALSE,
                               wchBaseDirExtract,
                               ProgressCallBackDoExtracting, &pcp);
        dfProgressStartcurrentStep += dfProgressStep;
      }

      if ((dfError == DFS_SUCCESS) && (*(lpVersionMap + i)))
      {
        // dfs ... do build
        //do InsertDirectoryinDfsFile or zip
        {
          BOOL fInsert;
          PROGRESSCBPARAMEP pcp;
          dfuLong32 dfTypeDir;

          pcp.dwMinProgress = dfProgressStartcurrentStep;
          pcp.dwMaxProgress = dfProgressStartcurrentStep + dfProgressStep;

          pcp.pSetExtractPosCallBack = pSetExtractPosCallBack;
          pcp.dfuPtrSetExtractPosCallBack = dfUserPtr;
          pcp.pConfirmBeforeCreatingFile = NULL;
          pcp.dfUserPtrBeforeCreatingFile = NULL;

          dfTypeDir = (pfsOrgNewDfs != NULL) ? TYPEDIR_PATCHFROMPREVIOUS :
            (fFirstVersionAsReference ?
             TYPEDIR_FILECRCONLY : TYPEDIR_FILEINSERTING_DEFLATE);

          // dfs ... do build
          //do InsertDirectoryinDfsFile or zip

            fInsert = DoInsertDirectoryFileSetPROV(DfsFileWrite, dfTypeDir,
                                             pfsOrgNewDfs, pfsDest,
                                             /*dfwVersionName */ NULL, NULL,
                                             pCprParam,
                                             ProgressCallBackDoExtracting,
                                             &pcp);

          CopyTagBuf(i,dfNbVersionWritten,DfsFileRead,DfsFileWrite);

          if (!fInsert)
            fRet = FALSE;
          else
            dfNbVersionWritten++;
          dfProgressStartcurrentStep += dfProgressStep;
        }

        if (pfsOrg == pfsOrgNewDfs)
          pfsOrgNewDfs = NULL;

        if (pfsOrgNewDfs != NULL)
        {
          FreeFileSet(pfsOrgNewDfs, fOrgNewDfsToDelete);
          DfsFree(pfsOrgNewDfs);
          pfsOrgNewDfs = NULL;
        }
      }

      if ((dfError != DFS_SUCCESS))
      {
        fRet = FALSE;
        break;
      }

      if ((pfsOrg != NULL) && (pfsOrg != pfsOrgNewDfs))
      {
        {
          FreeFileSet(pfsOrg, fFileOrgToDelete);
          DfsFree(pfsOrg);
        }
      }
      pfsOrg = NULL;

      //dfProgressStartcurrentStep+=dfProgressStep ;
      if ((fRet) && (dwMaxProgress != 0)
          && (dfLastDirExtr + 1 > dfDirStartExtr))
      {
        dfuLong32 dwNewPos;
        dwNewPos = dfProgressStartcurrentStep;
#ifdef _DEBUG
        OutputDebugString("$");
#endif


        if (pSetExtractPosCallBack != NULL)
          pSetExtractPosCallBack(dwNewPos, 0, dfUserPtr);
      }
    }


    if ((pfsOrgNewDfs != NULL))
    {
      FreeFileSet(pfsOrgNewDfs, fOrgNewDfsToDelete);
      DfsFree(pfsOrgNewDfs);
      if (pfsOrgNewDfs == pfsDest)
        pfsDest = NULL;
      pfsOrgNewDfs = NULL;
    }


    {
      if (pfsDest != NULL)
      {
        FreeFileSet(pfsDest, TRUE);
        DfsFree(pfsDest);
        pfsDest = NULL;
      }
    }


    if (ppFileSetCollection != NULL)
    {
      for (i = dfDirStartExtr; i <= dfLastDirExtr; i++)
        if (*(ppFileSetCollection + i) != NULL)
        {
          FreeFileSet(*(ppFileSetCollection + i), FALSE);
          DfsFree(*(ppFileSetCollection + i));
        }
      DfsFree(ppFileSetCollection);
    }


#if defined(_DEBUG) && defined(MSGTEST)
    if (!fRet)
      if (hwndMain != NULL)
        MessageBox(hwndMain, "We do subgenerating", fRet ? "TRUE" : "FALSE",
                   MB_OK | MB_ICONERROR);
#endif

    if ((fRet) && (dwMaxProgress != 0))
      if (pSetExtractPosCallBack != NULL)
        pSetExtractPosCallBack(dwMaxProgress, 0, dfUserPtr);
    //guiItem.SetProgressPos(dwMaxProgress);
  }

  if ((pDfsFileWrite == NULL))
    DfsClose(DfsFileWrite);
  return fRet;
}



/************/

